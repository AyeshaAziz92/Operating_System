#include<sys/types.h> 
#include<sys/ipc.h> 
#include<sys/msg.h> 
#include<stdio.h> 
#include<string.h>


#define Msg_Size 256

struct msg_t
{
	long msg_type;
	char msg_text[Msg_Size];
};

void main() 
{
	struct msg_t msg;

	
	msg.msg_type = 1;
	strcpy(msg.msg_text, "U");
	key_t key = 12345;
	int msg_id = msgget(key, 0666 | IPC_CREAT);
	size_t msg_length = strlen(msg.msg_text) + 1;
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "D");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 2;
	strcpy(msg.msg_text, "F");
	key = 12345;
	msg_id = msgget(key, 0666 | IPC_CREAT);
	msg_length = strlen(msg.msg_text) + 1;
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);
	
	msg.msg_type = 3;
	strcpy(msg.msg_text, "I");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);
	
	msg.msg_type = 3;
	strcpy(msg.msg_text, "S");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 1;
	strcpy(msg.msg_text, "N");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "C");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 2;
	strcpy(msg.msg_text, "A");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "I");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 1;
	strcpy(msg.msg_text, "I");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "P");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 2;
	strcpy(msg.msg_text, "I");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "L");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);
	
	msg.msg_type = 1;
	strcpy(msg.msg_text, "T");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "I");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 2;
	strcpy(msg.msg_text, "T");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "N");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);
	
	msg.msg_type = 1;
	strcpy(msg.msg_text, "Y");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 3;
	strcpy(msg.msg_text, "E");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

	msg.msg_type = 2;
	strcpy(msg.msg_text, "H");
	msgsnd(msg_id, &msg, msg_length, IPC_NOWAIT);

}

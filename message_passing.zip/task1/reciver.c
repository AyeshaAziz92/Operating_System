#include<sys/types.h> 
#include<sys/ipc.h> 
#include<sys/msg.h> 
#include<stdio.h> 
#include<string.h>


#define Msg_Size 256

struct msg_t
{
	long msg_type;
	char msg_text[Msg_Size];
};

void main() 
{
	struct msg_t msg;
	
	key_t key = 12345;
	int msg_id = msgget(key, 0666);
	printf("\n");
	for(int i = 0; i<5; i++)
	{
		msgrcv(msg_id, &msg, Msg_Size, 1, IPC_NOWAIT);
		printf("%s", msg.msg_text);
	}
	printf("\n");
	for(int i = 0; i<5; i++)
	{
		msgrcv(msg_id, &msg, Msg_Size, 2, IPC_NOWAIT);
		printf("%s", msg.msg_text);
	}
	printf("\n");
	for(int i = 0; i<10; i++)
	{
		msgrcv(msg_id, &msg, Msg_Size, 3, IPC_NOWAIT);
		printf("%s", msg.msg_text);
	}
	printf("\n");
	printf("\n");
}	


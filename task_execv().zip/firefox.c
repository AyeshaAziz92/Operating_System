#include <stdio.h>
#include <stdlib.h>



void main()
{

	system("/usr/bin/firefox www.google.com &");




}

#include <stdio.h>
#include <stdlib.h>



void main()
{

	system("gnome-terminal");




}

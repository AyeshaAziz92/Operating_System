#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>


void main(){
	printf("default theme system app loaded\n");
	
}

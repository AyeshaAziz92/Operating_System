#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>


void main(){
	printf("Sytem_apps.c\n");
	
	int Antivirus = fork();
	
	if(Antivirus == 0)
	{
			execv("./Antivirus",NULL);	
	}


	int background = fork();

	if(background  == 0)
	{
			execv("./background ",NULL);	
	}
	int screen_saver = fork();

	if(screen_saver == 0)
	{
			execv("./screen_saver",NULL);	
	}

	int default_theme = fork();

	if(default_theme == 0)
	{
			execv("./default_theme",NULL);	
	}

	
	else if (default_theme > 0)
	wait(NULL);
}

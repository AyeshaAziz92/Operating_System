#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>


void main(){
	
	printf("init\n");
	
	int driver_fork = fork();
	
	if(driver_fork == 0)
	{
			execv("./driver",NULL);	
	}
	
	int app_fork = fork();
	

	if(app_fork == 0)
	{
			execv("./app",NULL);	
	}

	wait(NULL);


	int system_apps_fork = fork();

	if(system_apps_fork == 0)
	{
			execv("./system_apps",NULL);	
	}


	wait(NULL);




}

#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>


void main(){
	printf("Driver.c\n");
	
	int gui = fork();
	
	if(gui == 0)
	{
			execv("./gui",NULL);	
	}


	int keyboard = fork();

	if(keyboard == 0)
	{
			execv("./keyboard",NULL);	
	}
	int mouse = fork();

	if(mouse == 0)
	{
			execv("./mouse",NULL);	
	}

	int usb = fork();

	if(usb == 0)
	{
			execv("./usb",NULL);	
	}

	int sd_card = fork();

	if(sd_card == 0)
	{
			execv("./sd_card",NULL);	
	}

	else if (sd_card > 0)
	wait(NULL);
}
